﻿using System;
using System.IO;
using System.Collections.Generic;
using WMPLib;
using System.Threading;
using System.Linq;

namespace MusicPlayer
{
    static class Program
    {
        private static List<string> musicPath = new List<string>();
        private static WindowsMediaPlayer player = new WindowsMediaPlayer();

        private static Thread musicThread;
        private static int volume = 2;
        private static double pausePosition;

        static void Main(string[] args)
        {
            GetPaths();
            RemovePaths();

            musicThread = new Thread(() => PlaySong());
            musicThread.Start();

            GetUserInput();
        }

        private static void GetUserInput()
        {
            while (true)
            {
                var input = Console.ReadLine();

                if (int.TryParse(input, out var vol) && vol >= 0 && vol <= 10)
                {
                    player.settings.volume = volume = vol;
                    CleanAndDisplayName();
                }
                else if (input.Equals("skip", StringComparison.InvariantCultureIgnoreCase))
                {
                    musicThread.Abort();
                    musicThread = new Thread(() => PlaySong());
                    musicThread.Start();
                    CleanAndDisplayName();
                }
                else if (input.Equals("mute", StringComparison.InvariantCultureIgnoreCase))
                {
                    player.settings.mute = !player.settings.mute;
                    CleanAndDisplayName();
                }
                else if (input.Equals("unmute", StringComparison.InvariantCultureIgnoreCase))
                {
                    player.settings.mute = false;
                    CleanAndDisplayName();
                }
                else if (input.Equals("pause", StringComparison.InvariantCultureIgnoreCase))
                {
                    pausePosition = player.controls.currentPosition;
                    player.controls.pause();
                    CleanAndDisplayName();
                }
                else if (input.Equals("play", StringComparison.InvariantCultureIgnoreCase))
                {
                    player.controls.currentPosition = pausePosition;
                    player.controls.play();
                    CleanAndDisplayName();
                }
                else if (input.Equals("exit", StringComparison.InvariantCultureIgnoreCase))
                {
                    Environment.Exit(0);
                }
                else
                {
                    CleanAndDisplayName();
                    Console.WriteLine($"Invalid Input: {input}");
                    Console.WriteLine("Please Try Again");
                }
            }
        }

        private static void CleanAndDisplayName()
        {
            Console.Clear();

            PrintControls();
            
            Console.WriteLine($"Currently Playing: {player.currentMedia?.name}");
        }

        private static void PrintControls()
        {
            var controls = "===========\nCommands:\nPause\nPlay\nSkip\nMute\nUnMute\n===========\nType a number for Volume Control: 1 - 10\n===========";
            Console.WriteLine(controls);
        }

        private static void PlaySong()
        {
            player.URL = musicPath[RandomSong()];
            player.settings.volume = volume;
            player.controls.play();
            CleanAndDisplayName();

            while (true)
            {
                Thread.Sleep(50);
                if (player.controls.currentPosition == 0)
                {
                    player.URL = musicPath[RandomSong()];
                    player.settings.volume = volume;
                    player.controls.play();
                    CleanAndDisplayName();
                    Thread.Sleep(50);
                }
            }
        }

        private static int RandomSong()
        {
            return new Random().Next(0, musicPath.Count);
        }

        private static void GetPaths()
        {
            string inputPath = "";

            do
            {
                Console.WriteLine("Please input a valid file path: ");
                inputPath = Console.ReadLine();
            } while (!Directory.Exists(inputPath));

            foreach (var path in Directory.GetFiles(inputPath, "*.*", SearchOption.AllDirectories))
            {
                if (string.IsNullOrEmpty(path))
                    continue;

                if (path.EndsWith(".mp3") || path.EndsWith(".mp4") || path.EndsWith(".m4a"))
                    musicPath.Add(path);
            }
        }

        private static void RemovePaths()
        {
            Console.WriteLine("Enter Paths to exclude (type \"done\" when finished):");

            List<string> excluded = new List<string>();

            while (true)
            {
                var input = Console.ReadLine();
                
                if (input.Equals("done", StringComparison.InvariantCultureIgnoreCase))
                    break;

                excluded.Add(input);
            }

            musicPath.RemoveAll(s => excluded.Any(e => s.Contains(e)));
        }
    }
}
